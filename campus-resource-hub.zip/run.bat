@echo off
echo ========================================================
echo Starting UniReserve - Campus Resource Booking Hub...
echo Open http://localhost:3000 in your browser
echo ========================================================
node server.js
pause
